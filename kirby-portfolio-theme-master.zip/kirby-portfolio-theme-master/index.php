<?php

require 'kirby/config/helpers.php';
require 'kirby/bootstrap.php';

echo (new Kirby)->render();
