<?php

twig(page()->template()->name(), $kirby->data);
