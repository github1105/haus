<?php

twig(page()->intendedTemplate()->name(), $kirby->data);
